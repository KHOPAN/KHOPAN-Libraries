package com.khopan.item.button;

public enum ButtonType {
	PUSH_BUTTON,
	TOGGLE_BUTTON,
	LABELED_TOGGLE_BUTTON,
	SWITCH,
	LABELED_SWITCH
}
