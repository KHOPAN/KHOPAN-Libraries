package com.khopan.item.button;

public abstract class ToggleButtonAdatper implements ToggleButtonListener {
	@Override
	public void toggleButtonEntered(ToggleButtonEvent Event) {}

	@Override
	public void toggleButtonPressed(ToggleButtonEvent Event) {}

	@Override
	public void toggleButtonReleased(ToggleButtonEvent Event) {}

	@Override
	public void toggleButtonClicked(ToggleButtonEvent Event) {}

	@Override
	public void toggleButtonOn(ToggleButtonEvent Event) {}

	@Override
	public void toggleButtonOff(ToggleButtonEvent Event) {}

	@Override
	public void toggleButtonExited(ToggleButtonEvent Event) {}
}
