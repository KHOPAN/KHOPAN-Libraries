package com.khopan.item.comboBox;

public abstract class ComboBoxAdapter implements ComboBoxListener {
	@Override
	public void comboBoxEntered(ComboBoxEvent Event) {}

	@Override
	public void comboBoxPressed(ComboBoxEvent Event) {}

	@Override
	public void comboBoxReleased(ComboBoxEvent Event) {}

	@Override
	public void comboBoxExited(ComboBoxEvent Event) {}

	@Override
	public void comboBoxSelected(ComboBoxEvent Event) {}

	@Override
	public void comboBoxScrolled(ComboBoxEvent Event) {}
}
