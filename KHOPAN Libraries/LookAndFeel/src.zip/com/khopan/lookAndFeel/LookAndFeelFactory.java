package com.khopan.lookAndFeel;

import javax.swing.UIManager;

public class LookAndFeelFactory {
	private LookAndFeelFactory() {}

	public static void setLookAndFeel(LookAndFeel LookAndFeel) {
		try {
			switch(LookAndFeel) {
			case SYSTEM:
				UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
				break;
			case CROSS:
				UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
				break;
			case METAL:
				UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
				break;
			case NIMBUS:
				UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
				break;
			case SYNTH:
				UIManager.setLookAndFeel("javax.swing.plaf.synth.SynthLookAndFeel");
				break;
			case WINDOWS:
				UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
				break;
			case MOTIF:
				UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
				break;
			}
		} catch(Throwable Errors) {
			Errors.printStackTrace();
		}
	}

	public static void setLookAndFeel(javax.swing.LookAndFeel LookAndFeel) {
		try {
			UIManager.setLookAndFeel(LookAndFeel);
		} catch(Throwable Errors) {
			Errors.printStackTrace();
		}
	}

	public static void setLookAndFeel(String LookAndFeel) {
		try {
			UIManager.setLookAndFeel(LookAndFeel);
		} catch(Throwable Errors) {
			Errors.printStackTrace();
		}
	}
}
