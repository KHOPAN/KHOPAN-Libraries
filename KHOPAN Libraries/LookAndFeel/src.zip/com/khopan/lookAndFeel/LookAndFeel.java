package com.khopan.lookAndFeel;

public enum LookAndFeel {
	SYSTEM,
	CROSS,
	METAL,
	NIMBUS,
	SYNTH,
	WINDOWS,
	MOTIF;
}
