package com.khopan.theme;

public class FieldName {
	public String FieldName;
	public Object FieldValue;

	public FieldName(String FieldName, Object FieldValue) {
		this.FieldName = FieldName;
		this.FieldValue = FieldValue;
	}
}
