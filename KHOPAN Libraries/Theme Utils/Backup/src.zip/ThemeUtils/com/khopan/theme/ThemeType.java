package com.khopan.theme;

public enum ThemeType {
	LIGHT_THEME,
	DARK_THEME,
	WINDOW10_THEME,
	CUSTOM_THEME;
}
