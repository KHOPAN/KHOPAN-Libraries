package com.khopan.theme;

public interface ThemeConstants {
	public static final String NORMAL_STATE = "normal-state";
	public static final String ENTERED_STATE = "entered-state";
	public static final String PRESSED_STATE = "pressed-state";
	public static final String DISABLED_STATE = "disabled-state";
}
