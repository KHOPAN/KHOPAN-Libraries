package com.khopan.theme;

public enum Themes {
	LIGHT_THEME,
	DARK_THEME,
	WINDOW10_THEME,
	CUSTOM_THEME;
}
