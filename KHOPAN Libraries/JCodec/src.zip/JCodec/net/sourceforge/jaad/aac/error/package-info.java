package net.sourceforge.jaad.aac.error;

/**
 * Error resilience and error protection classes.
 */
