package org.jcodec.api.transcode;

public enum Options {
    PROFILE, INTERLACED, DOWNSCALE

}
