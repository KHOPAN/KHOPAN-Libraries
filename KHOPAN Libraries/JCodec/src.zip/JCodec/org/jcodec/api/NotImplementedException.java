package org.jcodec.api;

public class NotImplementedException extends RuntimeException {

	public NotImplementedException(String string) {
		super(string);
	}

}
