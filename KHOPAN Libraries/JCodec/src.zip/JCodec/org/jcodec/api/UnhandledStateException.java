package org.jcodec.api;

public class UnhandledStateException extends RuntimeException {

	public UnhandledStateException(String string) {
		super(string);
	}

}
