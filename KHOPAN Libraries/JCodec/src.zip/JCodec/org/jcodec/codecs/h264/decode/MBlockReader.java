package org.jcodec.codecs.h264.decode;

/**
 * A reader for H.264 macroblocks
 * 
 * @author The JCodec project
 */
public class MBlockReader {

}
