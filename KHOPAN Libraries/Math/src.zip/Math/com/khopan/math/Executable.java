package com.khopan.math;

@FunctionalInterface
public interface Executable<T> {
	public void execute(T Type);
}
