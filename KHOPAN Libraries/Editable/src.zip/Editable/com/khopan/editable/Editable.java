package com.khopan.editable;

import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import com.khopan.math.MathUtils;
import com.khopan.message.Message;
import com.khopan.message.MessageHelper;
import com.khopan.message.MessageType;

public class Editable implements MouseListener, MouseMotionListener, KeyListener {
	public static final int DEFAULT_TRIGGER_RANGE = 5;

	public static final int MINIMUM_WIDTH = 10;
	public static final int MINIMUM_HEIGHT = 10;

	public static final String INFO_EDIT_MODE_ENABLED = "Edit Mode has been enabled.";
	public static final String INFO_EDIT_MODE_DISABLED = "Edit Mode has been disabled.";

	public static final Cursor DEFAULT_CURSOR = new Cursor(Cursor.DEFAULT_CURSOR);
	public static final Cursor MOVE_CURSOR = new Cursor(Cursor.MOVE_CURSOR);

	public static final Cursor NORTH_RESIZE_CURSOR = new Cursor(Cursor.N_RESIZE_CURSOR);
	public static final Cursor EAST_RESIZE_CURSOR = new Cursor(Cursor.E_RESIZE_CURSOR);
	public static final Cursor SOUTH_RESIZE_CURSOR = new Cursor(Cursor.S_RESIZE_CURSOR);
	public static final Cursor WEST_RESIZE_CURSOR = new Cursor(Cursor.W_RESIZE_CURSOR);

	public static final Cursor NORTH_EAST_RESIZE_CURSOR = new Cursor(Cursor.NE_RESIZE_CURSOR);
	public static final Cursor NORTH_WEST_RESIZE_CURSOR = new Cursor(Cursor.NW_RESIZE_CURSOR);
	public static final Cursor SOUTH_EAST_RESIZE_CURSOR = new Cursor(Cursor.SE_RESIZE_CURSOR);
	public static final Cursor SOUTH_WEST_RESIZE_CURSOR = new Cursor(Cursor.SW_RESIZE_CURSOR);

	private boolean EditMode;
	private Message Message;

	private Component Component;
	private Cursor MouseCursor;
	private int MouseX;
	private int MouseY;
	private int ComponentWidth;
	private int ComponentHeight;
	private int ComponentX;
	private int ComponentY;
	private int TriggerRange;

	public Editable() {
		this(DEFAULT_TRIGGER_RANGE, null);
	}

	public Editable(int TriggerRange) {
		this(TriggerRange, null);
	}

	public Editable(Message Message) {
		this(DEFAULT_TRIGGER_RANGE, Message);
	}

	public Editable(int TriggerRange, Message Message) {
		this.TriggerRange = TriggerRange;
		this.Message = Message;
	}

	@Override
	public void mouseClicked(MouseEvent Event) {
		Component = Event.getComponent();
	}

	@Override
	public void mousePressed(MouseEvent Event) {
		MouseX = Event.getX();
		MouseY = Event.getY();
		Component = Event.getComponent();
		ComponentWidth = Component.getWidth();
		ComponentHeight = Component.getHeight();
		ComponentX = Component.getX();
		ComponentY = Component.getY();
	}

	@Override
	public void mouseReleased(MouseEvent Event) {
		Component = Event.getComponent();
	}

	@Override
	public void mouseEntered(MouseEvent Event) {
		Component = Event.getComponent();
	}

	@Override
	public void mouseExited(MouseEvent Event) {
		Component = Event.getComponent();
	}

	@Override
	public void mouseDragged(MouseEvent Event) {
		if(EditMode) {
			Component = Event.getComponent();

			if(this.isCursor(Event, NORTH_RESIZE_CURSOR)) {
				this.northDrag(Event);
			} else if(this.isCursor(Event, EAST_RESIZE_CURSOR)) {
				this.eastDrag(Event);
			} else if(this.isCursor(Event, SOUTH_RESIZE_CURSOR)) {
				this.southDrag(Event);
			} else if(this.isCursor(Event, WEST_RESIZE_CURSOR)) {
				this.westDrag(Event);
			} else if(this.isCursor(Event, NORTH_WEST_RESIZE_CURSOR)) {
				this.northDrag(Event);
				this.westDrag(Event);
			} else if(this.isCursor(Event, NORTH_EAST_RESIZE_CURSOR)) {
				this.northDrag(Event);
				this.eastDrag(Event);
			} else if(this.isCursor(Event, SOUTH_EAST_RESIZE_CURSOR)) {
				this.southDrag(Event);
				this.eastDrag(Event);
			} else if(this.isCursor(Event, SOUTH_WEST_RESIZE_CURSOR)) {
				this.southDrag(Event);
				this.westDrag(Event);
			} else if(this.isCursor(Event, MOVE_CURSOR)) {
				this.moveDrag(Event);
			}
		}
	}

	private void northDrag(MouseEvent Event) {
		if((ComponentY + ComponentHeight) - ((Component.getY() + Event.getY()) - MouseY) >= MINIMUM_HEIGHT) {
			Component.setLocation(Component.getX(), (Component.getY() + Event.getY()) - MouseY);
			Component.setSize(Component.getWidth(), (ComponentY + ComponentHeight) - Component.getY());
		} else {
			Component.setSize(Component.getWidth(), MINIMUM_HEIGHT);
		}
	}

	private void eastDrag(MouseEvent Event) {
		if(Event.getX() >= MINIMUM_WIDTH) {
			Component.setSize(Event.getX(), Component.getHeight());
		} else {
			Component.setSize(MINIMUM_WIDTH, Component.getHeight());
		}
	}

	private void southDrag(MouseEvent Event) {
		if(Event.getY() >= MINIMUM_HEIGHT) {
			Component.setSize(Component.getWidth(), Event.getY());
		} else {
			Component.setSize(Component.getWidth(), MINIMUM_HEIGHT);
		}
	}

	private void westDrag(MouseEvent Event) {
		if((ComponentX + ComponentWidth) - ((Component.getX() + Event.getX()) - MouseX) >= MINIMUM_WIDTH) {
			Component.setLocation((Component.getX() + Event.getX()) - MouseX, Component.getY());
			Component.setSize((ComponentX + ComponentWidth) - Component.getX(), Component.getHeight());
		} else {
			Component.setSize(MINIMUM_WIDTH, Component.getHeight());
		}
	}

	private void moveDrag(MouseEvent Event) {
		Component.setLocation((Event.getX() + Component.getX()) - MouseX, (Event.getY() + Component.getY()) - MouseY);
	}

	@Override
	public void mouseMoved(MouseEvent Event) {
		if(EditMode) {
			Component = Event.getComponent();
			MouseCursor = DEFAULT_CURSOR;

			if(Event.getY() <= TriggerRange) {
				MouseCursor = NORTH_RESIZE_CURSOR;
			} else if(Event.getX() >= Component.getWidth() - TriggerRange) {
				MouseCursor = EAST_RESIZE_CURSOR;
			} else if(Event.getY() >= Component.getHeight() - TriggerRange) {
				MouseCursor = SOUTH_RESIZE_CURSOR;
			} else if(Event.getX() <= TriggerRange) {
				MouseCursor = WEST_RESIZE_CURSOR;
			}

			if((Event.getX() <= TriggerRange) && (Event.getY() <= TriggerRange)) {
				MouseCursor = NORTH_WEST_RESIZE_CURSOR;
			} else if((Event.getY() <= TriggerRange) && (Event.getX() >= Component.getWidth() - TriggerRange)) {
				MouseCursor = NORTH_EAST_RESIZE_CURSOR;
			} else if((Event.getX() >= Component.getWidth() - TriggerRange) && (Event.getY() >= Component.getHeight() - TriggerRange)) {
				MouseCursor = SOUTH_EAST_RESIZE_CURSOR;
			} else if((Event.getY() >= Component.getHeight() - TriggerRange) && (Event.getX() <= TriggerRange)) {
				MouseCursor = SOUTH_WEST_RESIZE_CURSOR;
			}

			if((Event.getX() >= TriggerRange) && (Event.getY() >= TriggerRange) && (Event.getX() <= Component.getWidth() - TriggerRange) && (Event.getY() <= Component.getHeight() - TriggerRange)) {
				MouseCursor = MOVE_CURSOR;
			}

			this.setCursor(Event, MouseCursor);
		}
	}

	@Override
	public void keyTyped(KeyEvent Event) {

	}

	@Override
	public void keyPressed(KeyEvent Event) {
		if(Event.getKeyCode() == KeyEvent.VK_E) {
			if(EditMode) {
				EditMode = false;
				Component.setCursor(DEFAULT_CURSOR);
				MessageHelper.INSTANCE.showMessage(Message, INFO_EDIT_MODE_DISABLED, MessageType.INFO, 1000);
			} else {
				EditMode = true;

				if(Component != null) {
					Point MouseLocation = Component.getMousePosition();

					if(MouseLocation != null) {
						int ID = (int) MathUtils.map(Math.random(), 0.0d, 1.0d, Integer.MIN_VALUE, Integer.MAX_VALUE);
						long Time = System.nanoTime();
						MouseEvent MouseEvent = new MouseEvent(Component, ID, Time, 0, (int) MouseLocation.getX(), (int) MouseLocation.getY(), 0, false);

						this.mouseMoved(MouseEvent);
					}
				}

				MessageHelper.INSTANCE.showMessage(Message, INFO_EDIT_MODE_ENABLED, MessageType.INFO, 1000);
			}
		}
	}

	@Override
	public void keyReleased(KeyEvent Event) {

	}

	public static void addEditable(Component Component) {
		Editable.addEditable(Component, DEFAULT_TRIGGER_RANGE);
	}

	public static void addEditable(Component Component, int ResizeRange) {
		Editable.addEditable(Component, new Editable(ResizeRange));
	}

	public static void addEditable(Component Component, Editable Editable) {
		Container RootParent = MathUtils.getParent(Component);

		Component.addMouseListener(Editable);
		Component.addMouseMotionListener(Editable);

		if(RootParent != null) {
			RootParent.setFocusable(true);
			RootParent.addKeyListener(Editable);
		}
	}

	private void setCursor(MouseEvent Event, Cursor Cursor) {
		Event.getComponent().setCursor(Cursor);
	}

	private boolean isCursor(MouseEvent Event, Cursor Cursor) {
		return Event.getComponent().getCursor().equals(Cursor);
	}
}
