package com.khopan.application.utils.menuBar;

public abstract class MenuComponent {}
