package com.khopan.application.utils.menuBar;

public enum ItemType {
	NORMAL,
	RADIO,
	CHECKBOX
}
