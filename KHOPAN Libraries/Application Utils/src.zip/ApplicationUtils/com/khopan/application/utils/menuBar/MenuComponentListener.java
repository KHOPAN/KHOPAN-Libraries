package com.khopan.application.utils.menuBar;

public interface MenuComponentListener {
	public void menuComponentSelected(MenuComponentEvent Event);
}
