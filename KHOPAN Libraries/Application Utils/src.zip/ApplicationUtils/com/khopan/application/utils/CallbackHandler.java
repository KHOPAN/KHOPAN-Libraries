package com.khopan.application.utils;

public interface CallbackHandler<T> {
	public void callback(T Data);
}
