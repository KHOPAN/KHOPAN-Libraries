package com.khopan.project.textEditor.plugin;

import java.awt.event.KeyEvent;

public interface KeyHandler {
	public void keyAction(KeyEvent Event);
}
