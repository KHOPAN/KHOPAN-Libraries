package com.khopan.project.textEditor.plugin.api;

import com.khopan.project.textEditor.TextEditor;

public interface IPluginInitializer {
	public void init(TextEditor Editor);
}
