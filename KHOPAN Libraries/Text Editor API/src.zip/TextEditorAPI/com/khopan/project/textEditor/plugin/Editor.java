package com.khopan.project.textEditor.plugin;

public class Editor {
	public Editor() {

	}
}
