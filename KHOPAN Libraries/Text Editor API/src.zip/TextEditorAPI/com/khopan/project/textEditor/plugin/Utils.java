package com.khopan.project.textEditor.plugin;

import java.util.Calendar;
import java.util.Date;

public class Utils {
	public Utils() {

	}

	public Date getTime() {
		return Calendar.getInstance().getTime();
	}
}
