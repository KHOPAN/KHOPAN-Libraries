package com.khopan.message;

public interface Message {
	public void showMessage(String Info, MessageType Type);
	public void hideMessage();
}
