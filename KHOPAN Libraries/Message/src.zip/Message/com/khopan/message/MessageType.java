package com.khopan.message;

public enum MessageType {
	INFO,
	WARNING,
	ERROR,
	FATAL_ERROR;
}
