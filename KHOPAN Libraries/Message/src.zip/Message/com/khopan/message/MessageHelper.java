package com.khopan.message;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import com.khopan.message.popup.PopupMessage;
import com.khopan.message.popup.PopupTheme;

public class MessageHelper {
	public static final MessageHelper INSTANCE = new MessageHelper();

	private int Time;
	private Timer Timer;
	private TimerTask TimerTask;
	private Message Message;
	private MessageType Type;

	public void showMessage(Message Message, String MessageText, MessageType Type, int Timeout) {
		this.showPopupMessageMessage(Message, MessageText, Type, Timeout, null);
	}

	public void showPopupMessageMessage(Message Message, String MessageText, MessageType Type, int Timeout, PopupTheme Theme) {
		if(Time == 0) {
			this.Message = Message;
			this.Type = Type;

			if(this.Message == null) {
				this.Message = new PopupMessage(Theme);
			}

			if(this.Type == null) {
				this.Type = MessageType.INFO;
			}

			Time = 0;
			Timer = new Timer();
			TimerTask = new TimerTask() {
				@Override
				public void run() {
					if(Time == 0) {
						MessageHelper.this.Message.showMessage(MessageText, MessageHelper.this.Type);
					} else if(Time >= Timeout) {
						MessageHelper.this.Message.hideMessage();
						Time = 0;
						Timer.cancel();
						return;
					}

					Time++;
				}
			};

			Timer.schedule(TimerTask, new Date(), 1);
		}
	}
}
