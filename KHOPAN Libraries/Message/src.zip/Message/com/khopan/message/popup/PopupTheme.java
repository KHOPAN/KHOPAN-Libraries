package com.khopan.message.popup;

import java.awt.Color;

public class PopupTheme {
	public static final Color DEFAULT_INFO_FOREGROUND = new Color(0xEFF0F4);
	public static final Color DEFAULT_INFO_BACKGROUND = new Color(0x333436);

	public static final Color DEFAULT_WARNING_FOREGROUND = new Color(0xF4C82D);
	public static final Color DEFAULT_WARNING_BACKGROUND = new Color(0x333436);

	public static final Color DEFAULT_ERROR_FOREGROUND = new Color(0xE11E46);
	public static final Color DEFAULT_ERROR_BACKGROUND = new Color(0x333436);

	public static final Color DEFAULT_FATAL_ERROR_FOREGROUND = new Color(0xFF142F);
	public static final Color DEFAULT_FATAL_ERROR_BACKGROUND = new Color(0x333436);

	private Color InfoForeground;
	private Color InfoBackground;

	private Color WarningForeground;
	private Color WarningBackground;

	private Color ErrorForeground;
	private Color ErrorBackground;

	private Color FatalErrorForeground;
	private Color FatalErrorBackground;

	public PopupTheme() {
		this(
				DEFAULT_INFO_FOREGROUND,
				DEFAULT_INFO_BACKGROUND,
				DEFAULT_WARNING_FOREGROUND,
				DEFAULT_WARNING_BACKGROUND,
				DEFAULT_ERROR_FOREGROUND,
				DEFAULT_ERROR_BACKGROUND,
				DEFAULT_FATAL_ERROR_FOREGROUND,
				DEFAULT_FATAL_ERROR_BACKGROUND
				);
	}

	public PopupTheme(
			Color InfoForeground,
			Color InfoBackground,
			Color WarningForeground,
			Color WarningBackground,
			Color ErrorForeground,
			Color ErrorBackground,
			Color FatalErrorForeground,
			Color FatalErrorBackground
			) {
		this.InfoForeground = InfoForeground;
		this.InfoBackground = InfoBackground;
		this.WarningForeground = WarningForeground;
		this.WarningBackground = WarningBackground;
		this.ErrorForeground = ErrorForeground;
		this.ErrorBackground = ErrorBackground;
		this.FatalErrorForeground = FatalErrorForeground;
		this.FatalErrorBackground = FatalErrorBackground;
	}

	public Color getInfoForeground() {
		return InfoForeground;
	}

	public Color getInfoBackground() {
		return InfoBackground;
	}

	public Color getWarningForeground() {
		return WarningForeground;
	}

	public Color getWarningBackground() {
		return WarningBackground;
	}

	public Color getErrorForeground() {
		return ErrorForeground;
	}

	public Color getErrorBackground() {
		return ErrorBackground;
	}

	public Color getFatalErrorForeground() {
		return FatalErrorForeground;
	}

	public Color getFatalErrorBackground() {
		return FatalErrorBackground;
	}

	public void setInfoForeground(Color InfoForeground) {
		this.InfoForeground = InfoForeground;
	}

	public void setInfoBackground(Color InfoBackground) {
		this.InfoBackground = InfoBackground;
	}

	public void setWarningForeground(Color WarningForeground) {
		this.WarningForeground = WarningForeground;
	}

	public void setWarningBackground(Color WarningBackground) {
		this.WarningBackground = WarningBackground;
	}

	public void setErrorForeground(Color ErrorForeground) {
		this.ErrorForeground = ErrorForeground;
	}

	public void setErrorBackground(Color ErrorBackground) {
		this.ErrorBackground = ErrorBackground;
	}

	public void setFatalErrorForeground(Color FatalErrorForeground) {
		this.FatalErrorForeground = FatalErrorForeground;
	}

	public void setFatalErrorBackground(Color FatalErrorBackground) {
		this.FatalErrorBackground = FatalErrorBackground;
	}
}
