package com.khopan.message.popup;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;

import com.khopan.math.MathUtils;
import com.khopan.message.Message;
import com.khopan.message.MessageType;

public class PopupMessage implements Message {
	public static final int SCREEN_WIDTH = (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
	public static final int SCREEN_HEIGHT = (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();

	private JFrame Frame;
	private PopupTheme Theme;

	public PopupMessage(PopupTheme Theme) {
		if(Theme != null) {
			this.Theme = Theme;
		} else {
			this.Theme = new PopupTheme();
		}
	}

	@Override
	public void showMessage(String Message, MessageType Type) {
		JFrame.setDefaultLookAndFeelDecorated(true);

		Frame = new JFrame();
		Frame.setUndecorated(true);
		Frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		Frame.add(new Label(Message, Type));
		Frame.pack();
		Frame.setSize(Frame.getWidth(), Frame.getHeight() + 10);
		Frame.setLocation((SCREEN_WIDTH - Frame.getWidth()) / 2, SCREEN_HEIGHT / 2);
		Frame.setOpacity(0.0f);
		Frame.setFocusableWindowState(false);
		Frame.setBackground(new Color(0.0f, 0.0f, 0.0f, 0.0f));
		Frame.setVisible(true);

		this.fade(Frame, 0.0f, 1.0f, 1000, false);
	}

	@Override
	public void hideMessage() {
		this.fade(Frame, 1.0f, 0.0f, 1000, true);
	}

	private int Progress;
	private Timer Timer;
	private TimerTask TimerTask;

	private void fade(JFrame Frame, float From, float To, int FPS, boolean Dispose) {
		Progress = 0;
		Timer = new Timer();
		TimerTask = new TimerTask() {
			@Override
			public void run() {
				Progress++;

				if(Progress > 100) {
					Timer.cancel();

					if(Dispose) {
						Frame.dispose();
					}

					return;
				}

				Frame.setOpacity((float) MathUtils.map(Progress, 0.0d, 100.0d, From, To));
			}
		};

		Timer.schedule(TimerTask, new Date(), 1000 / FPS);
	}

	private class Label extends JLabel {
		private static final long serialVersionUID = 8481282896007667972L;

		private String Message;
		private MessageType Type;
		private String Text;

		public Label(String Message, MessageType Type) {
			this.Message = Message;
			this.Type = Type;
			this.Text = (this.Type.equals(MessageType.INFO) ? " " : this.Type.equals(MessageType.WARNING) ? " Warning: " : this.Type.equals(MessageType.ERROR) ? " Error: " : " Fatal Error: ") + this.Message + " ";

			this.setFont(new Font("Consolas", Font.BOLD, 16));
			this.setText(Text);
		}

		public Graphics2D Graphics2D;
		public FontMetrics FontMetrics;
		public Color Foreground;
		public Color Background;

		@Override
		public void paint(Graphics Graphics) {
			switch(Type) {
			case INFO:
				Foreground = Theme.getInfoForeground();
				Background = Theme.getInfoBackground();
				break;
			case WARNING:
				Foreground = Theme.getWarningForeground();
				Background = Theme.getWarningBackground();
				break;
			case ERROR:
				Foreground = Theme.getErrorForeground();
				Background = Theme.getErrorBackground();
				break;
			case FATAL_ERROR:
				Foreground = Theme.getFatalErrorForeground();
				Background = Theme.getFatalErrorBackground();
				break;
			}

			Graphics2D = (Graphics2D) Graphics;
			Graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
			Graphics2D.setColor(Background);
			Graphics2D.fillRoundRect(0, 0, this.getWidth(), this.getHeight(), 15, 15);
			Graphics2D.setFont(new Font("Consolas", Font.BOLD, 16));

			FontMetrics = this.getFontMetrics(this.getFont());

			Graphics2D.setColor(Foreground);
			Graphics2D.drawString(Text, (this.getWidth() - FontMetrics.stringWidth(Text)) / 2, this.getHeight() / 2 + FontMetrics.getHeight() / 4);
		}
	}
}
