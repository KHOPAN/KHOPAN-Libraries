package com.khopan.parser.json.interpreter;

@FunctionalInterface
public interface JsonFinder {
	public void found(Object FoundObject);
}
