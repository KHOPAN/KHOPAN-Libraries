package com.khopan.parser.json.interpreter;

public enum KeyType {
	REQUIRED,
	OPTIONAL;
}
